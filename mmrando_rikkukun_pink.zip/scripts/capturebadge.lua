CaptureBadgeSections = {


  --List out all of the locations that can be capturable

  --Format: 
  --"@Title of Check/Flavor Text on Check"

  --South Clock Town
  "@Clock Tower Balcony/Clock Tower HP",
  "@Clock Town Business Scrub/Give him Moon's Tear",
  "@Carnival Tower Chest/Open On Final Day",
  "@South Clock Town Nook/South Clock Town Lower Chest",
  "@Clock Town Tunnels/Clock Town Tunnels Deku Nut - Not in Casual Logic",
  "@Clock Town Mailboxes/Postbox Item",


  --West Clock Town
  "@Curiosity Shop - Open 10 PM - 5 AM/500 Rupees Purchase - Final Night",
  "@Curiosity Shop - Open 10 PM - 5 AM/5 Rupee Sale - Mushroom or Half Milk",
  "@Curiosity Shop - Open 10 PM - 5 AM/20 Rupee Sale - Fish, Bugs, Fairy, Milk, Potions, or Water",
  "@Curiosity Shop - Open 10 PM - 5 AM/50 Rupee Sale - Poe",
  "@Curiosity Shop - Open 10 PM - 5 AM/200 Rupee Sale - Big Poe, Chateau, or Gold Dust",



  "@Clock Town Bank/200 Rupees Deposit",
  "@Clock Town Bank/500 Rupees Deposit",
  "@Clock Town Bank/1000 Rupees Deposit",



  "@Lottery Shop/Win the Lottery",
  "@West Clock Town/Rosa Sisters Gift - Night 1 or 2",
  "@Swordsman's School/Expert Swordsman Prize",
  "@Post Office/Postman Counting Game - Day 1: 3 PM - Midnight, Day 2: 5 PM - Midnight (if Letter to Kafei is Mailed)",

  --Laundry Pool

  "@Listen To Guru Guru/Night 1 or 2",
  "@Clock Town Stray Fairy/Get It",

  "@Curiosity Shop Backroom/Gift From Kafei - Day 2: 4:30 PM",
  "@Curiosity Shop Backroom/Curiosity Shop Man Gift - Final Day: 1 PM - 9 PM First Item",
  "@Curiosity Shop Backroom/Curiosity Shop Man Gift - Final Day: 1 PM - 9 PM Second Item",

  --East Clock Town
  "@East Clock Town/East Clock Town Chest",

  "@Honey and Darling - Open 6 AM - 10 PM/Beat All Three Days",
  "@Honey and Darling - Open 6 AM - 10 PM/Beat Any Day",

  "@Town Shooting Gallery - Open 6 AM - 10 PM/40 Points Prize",
  "@Town Shooting Gallery - Open 6 AM - 10 PM/Perfect Score",

  "@Treasure Box Shop - Open 6 AM - 10 PM/Treasure Chest Game Goron Prize",
  "@Treasure Box Shop - Open 6 AM - 10 PM/Treasure Chest Game Human Prize",
  "@Treasure Box Shop - Open 6 AM - 10 PM/Treasure Chest Game Deku Prize",
  "@Treasure Box Shop - Open 6 AM - 10 PM/Treasure Chest Game Zora Prize",

  "@Milk Bar - Open 10 PM PM - 5 AM/Milk Bar Performance - Night 1 or 2 10 PM - 5 AM",
  "@Milk Bar - Open 10 PM PM - 5 AM/Delivery To Madame Aroma - Final Night",
  "@Milk Bar - Open 10 PM PM - 5 AM/Chateau Purchase - 200 Rupees",
  "@Milk Bar - Open 10 PM PM - 5 AM/Milk Purchase - 20 Rupees",

  "@Mayor's Residence - Open 10 AM - 8 PM/Gift From Madame Aroma",
  "@Mayor's Residence - Open 10 AM - 8 PM/Calm The Council",

  "@Bomber's Secret Tunnel/Bombers' Hidden Treasure",

  "@Stock Pot Inn/Inn Employee Room Chest - Final Night",
  "@Stock Pot Inn/Room Reservation Mixup - Day 1: from 1:45 PM to 4 PM",
  "@Stock Pot Inn/Inn Guest Room Chest",
  "@Stock Pot Inn/Midnight Item From Anju - Night 1: 11:30 PM",
  "@Stock Pot Inn/Grandma Story Time - Day 1 or 2 - Carnival of Time",
  "@Stock Pot Inn/Grandma Story Time - Day 1 or 2 - Four Giants",
  "@Stock Pot Inn/Toilet Hand Gift - Midnight - 6 AM",
  "@Stock Pot Inn/Couple's Mask - Final Night 4:30 AM",

  --North Clock Town
  "@Save The Old Lady/Night 1: 12:20",
  "@North Clock Town Tree/North Clock Town Tree HP",
  "@Red Bomber/Catch The Bombers",
  "@Keaton Grass Circle/Keaton Quiz Reward",
  "@Clock Town Tingle Maps/Map: Clock Town",
  "@Clock Town Tingle Maps/Map: Swamp",
  "@Save The Old Lady/Night 1: 12:20",
  "@Deku Playground/Beat All Three Days",
  "@Deku Playground/Beat Any Day",
  "@Clock Town Great Fairy/Enter while Transformed",
  "@Clock Town Great Fairy/Stray Fairy",

  --Termina Field
  "@Gossip Stones Puzzle Grottos/Play a Dungeon Song in all four grottos",
  "@East Pillar Bombchu Chest/Climb the pillar",
  "@Learn Kamaro Dance/From Midnight to 6 AM",
  "@Termina Field North Grotto/Kill the Dodongos",
  "@West Termina Field Grotto/Shoot the Beehives",
  "@Underwater Chest/Open it",
  "@Termina Field Cow Grotto/Left Cow",
  "@Termina Field Cow Grotto/Right Cow",

  "@Southeast Termina Field/Chest in the grass",
  "@Southeast Termina Field/Chest on a stump",
  "@Southeast Termina Field/Grotto near stump",

  "@Butterflies In The Grass/Kill Peahats (Daytime Only)",
  "@Empty Grotto By Observatory/Follow Scrub With Telescope",
  "@Moon's Tear/Look at Skull Kid through the telescope",


  --Road to the Swamp
  "@Swamp Path Pit Chest/Get in",
  "@Swamp Path Bat Tree Heart Piece/Kill the bat and climb",

  "@Swamp Shooting Gallery - Open 6 AM - 10 PM/Perfect Score",
  "@Swamp Shooting Gallery - Open 6 AM - 10 PM/Perfect Score With Time Left Over",

  "@Swamp Tingle Maps/Map: Swamp",
  "@Swamp Tingle Maps/Map: Mountain",

  --Southern Swamp
  "@Swamp Tourist Center/Gift From Saving Koume",
  "@Swamp Tourist Center/Show Photo of Tingle or Deku King",
  "@Swamp Tourist Center/Show Photo of Swamp",
  "@Swamp Tourist Center/Show Photo of Big Octo or Monkey",
  "@Swamp Tourist Center/Post Woodfall Temple Archery Game",

  "@Swamp Business Scrub/Give Land Title Deed",
  "@Swamp Business Scrub/Buy Magic Beans - 10 Rupees",
  "@Swamp Business Scrub/Use Flower",

  "@Kotake Magic Potion Shop/Blue Potion (60 Rupees)",
  "@Kotake Magic Potion Shop/Green Potion (10 Rupees)",
  "@Kotake Magic Potion Shop/Red Potion (20 Rupees)",
  "@Kotake Magic Potion Shop/Trade Shrooms For Blue Potion",
  "@Kotake Red Potion Bottle/Talk to Kotake after seeing Koume in Woods",
  "@Woods of Mystery Grotto/Day 2",

  "@Song of Soaring Engraving/Learn it",
  "@Southern Swamp Grotto/Get in",

  --Swamp Spider House
  "@Swamp Spider House Skulltullas First 15/Main Room in Water",
  "@Swamp Spider House Skulltullas First 15/Main Room Dirt Patch Left",
  "@Swamp Spider House Skulltullas First 15/Main Room Dirt Patch Right",
  "@Swamp Spider House Skulltullas First 15/Main Room Pillar",
  "@Swamp Spider House Skulltullas First 15/Main Room Pot",
  "@Swamp Spider House Skulltullas First 15/Stone Room Left Crate",
  "@Swamp Spider House Skulltullas First 15/Stone Room Right Crate",
  "@Swamp Spider House Skulltullas First 15/Stone Room on Wall",
  "@Swamp Spider House Skulltullas First 15/Stone Room on Monument",
  "@Swamp Spider House Skulltullas First 15/Stone Room Behind Torch",
  "@Swamp Spider House Skulltullas First 15/Main Room Upper Pillar",
  "@Swamp Spider House Skulltullas First 15/Main Room Upper Wall",
  "@Swamp Spider House Skulltullas First 15/Main Room Dirt Patch Upper",
  "@Swamp Spider House Skulltullas First 15/Jar Room Beehive 1",
  "@Swamp Spider House Skulltullas First 15/Jar Room Beehive 2",
  
  "@Swamp Spider House Skulltullas Second 15/Jar Room Left Big Jar",
  "@Swamp Spider House Skulltullas Second 15/Jar Room Right Big Jar",
  "@Swamp Spider House Skulltullas Second 15/Jar Room Pile of Pots",
  "@Swamp Spider House Skulltullas Second 15/Jar Room Vine Alcove",
  "@Swamp Spider House Skulltullas Second 15/Gold Room Hive",
  "@Swamp Spider House Skulltullas Second 15/Gold Room Pillar",
  "@Swamp Spider House Skulltullas Second 15/Gold Room on Wall",
  "@Swamp Spider House Skulltullas Second 15/Gold Room Ladder",
  "@Swamp Spider House Skulltullas Second 15/Tree Room Tree 1",
  "@Swamp Spider House Skulltullas Second 15/Tree Room Tree 2",
  "@Swamp Spider House Skulltullas Second 15/Tree Room Tree 3",
  "@Swamp Spider House Skulltullas Second 15/Tree Room Beehive",
  "@Swamp Spider House Skulltullas Second 15/Tree Room Tall Grass 1",
  "@Swamp Spider House Skulltullas Second 15/Tree Room Tall Grass 2",
  "@Swamp Spider House Skulltullas Second 15/Jar Room on Wall",

  "@Swamp Spider House/Collect 30 Tokens",

  --Deku Palace
  "@Magic Bean Seller Grotto/Free Sample",
  "@Magic Bean Seller Grotto/Get to the chest",
  "@Monkey Teaching Sonata of Awakening/Use Deku Pipes in front of the monkey",
  "@Deku Palace Heart Piece/Get it",
  "@Deku Shrine Race/Race with Deku Butler",

  --Woodfall Area
  "@Woodfall Great Fairy Fountain/15 Stray Fairies in Woodfall Temple",
  "@Woodfall Chests/Tall Stump",
  "@Woodfall Chests/Water Level Stump",
  "@Woodfall Chests/Behind Temple Platform",

  --Woodfall Temple in Woodfall
  "@Woodfall Temple/Chest in Platform Room - Small Key",
  "@Woodfall Temple/Fight Turtles - Map",
  "@Woodfall Temple/Fight Dragonflies - Compass",
  "@Woodfall Temple/Dinolfos Mini Boss - Hero's Bow",
  "@Woodfall Temple/Boss Key Chest",
  "@Woodfall Temple/Odolwa",
  "@Woodfall Temple/Oath to Order",
  "@Woodfall Temple Stray Fairies/Entrance Fairy",
  "@Woodfall Temple Stray Fairies/Entrance Platform Chest",
  "@Woodfall Temple Stray Fairies/Kill Deku Baba in Main Room",
  "@Woodfall Temple Stray Fairies/Pots in Main Room",
  "@Woodfall Temple Stray Fairies/Platform Room Beehive",
  "@Woodfall Temple Stray Fairies/Kill Skulltula in Bridge Room",
  "@Woodfall Temple Stray Fairies/Bridge Room Beehive",
  "@Woodfall Temple Stray Fairies/Dark Room Black Boes",
  "@Woodfall Temple Stray Fairies/Main Room Bubble",
  "@Woodfall Temple Stray Fairies/Main Room Switch",
  "@Woodfall Temple Stray Fairies/Bridge Room Bubble",
  "@Woodfall Temple Stray Fairies/Final Room Lower Right Bubble",
  "@Woodfall Temple Stray Fairies/Final Room Upper Right Bubble",
  "@Woodfall Temple Stray Fairies/Final Room Upper Left Bubble",
  "@Woodfall Temple Stray Fairies/Final Room Pillar Bubble",

  --Woodfall Temple in Snowhead
  "@Woodfall Temple in Snowhead/Chest in Platform Room - Small Key",
  "@Woodfall Temple in Snowhead/Fight Turtles - Map",
  "@Woodfall Temple in Snowhead/Fight Dragonflies - Compass",
  "@Woodfall Temple in Snowhead/Dinolfos Mini Boss - Hero's Bow",
  "@Woodfall Temple in Snowhead/Boss Key Chest",
  "@Woodfall Temple in Snowhead/Odolwa",
  "@Woodfall Temple in Snowhead/Oath to Order",
  "@Woodfall Temple Stray Fairies in Snowhead/Entrance Fairy",
  "@Woodfall Temple Stray Fairies in Snowhead/Entrance Platform Chest",
  "@Woodfall Temple Stray Fairies in Snowhead/Kill Deku Baba in Main Room",
  "@Woodfall Temple Stray Fairies in Snowhead/Pots in Main Room",
  "@Woodfall Temple Stray Fairies in Snowhead/Platform Room Beehive",
  "@Woodfall Temple Stray Fairies in Snowhead/Kill Skulltula in Bridge Room",
  "@Woodfall Temple Stray Fairies in Snowhead/Bridge Room Beehive",
  "@Woodfall Temple Stray Fairies in Snowhead/Dark Room Black Boes",
  "@Woodfall Temple Stray Fairies in Snowhead/Main Room Bubble",
  "@Woodfall Temple Stray Fairies in Snowhead/Main Room Switch",
  "@Woodfall Temple Stray Fairies in Snowhead/Bridge Room Bubble",
  "@Woodfall Temple Stray Fairies in Snowhead/Final Room Lower Right Bubble",
  "@Woodfall Temple Stray Fairies in Snowhead/Final Room Upper Right Bubble",
  "@Woodfall Temple Stray Fairies in Snowhead/Final Room Upper Left Bubble",
  "@Woodfall Temple Stray Fairies in Snowhead/Final Room Pillar Bubble",

  --Woodfall Temple in Great Bay
  "@Woodfall Temple in Great Bay/Chest in Platform Room - Small Key",
  "@Woodfall Temple in Great Bay/Fight Turtles - Map",
  "@Woodfall Temple in Great Bay/Fight Dragonflies - Compass",
  "@Woodfall Temple in Great Bay/Dinolfos Mini Boss - Hero's Bow",
  "@Woodfall Temple in Great Bay/Boss Key Chest",
  "@Woodfall Temple in Great Bay/Odolwa",
  "@Woodfall Temple in Great Bay/Oath to Order",
  "@Woodfall Temple Stray Fairies in Great Bay/Entrance Fairy",
  "@Woodfall Temple Stray Fairies in Great Bay/Entrance Platform Chest",
  "@Woodfall Temple Stray Fairies in Great Bay/Kill Deku Baba in Main Room",
  "@Woodfall Temple Stray Fairies in Great Bay/Pots in Main Room",
  "@Woodfall Temple Stray Fairies in Great Bay/Platform Room Beehive",
  "@Woodfall Temple Stray Fairies in Great Bay/Kill Skulltula in Bridge Room",
  "@Woodfall Temple Stray Fairies in Great Bay/Bridge Room Beehive",
  "@Woodfall Temple Stray Fairies in Great Bay/Dark Room Black Boes",
  "@Woodfall Temple Stray Fairies in Great Bay/Main Room Bubble",
  "@Woodfall Temple Stray Fairies in Great Bay/Main Room Switch",
  "@Woodfall Temple Stray Fairies in Great Bay/Bridge Room Bubble",
  "@Woodfall Temple Stray Fairies in Great Bay/Final Room Lower Right Bubble",
  "@Woodfall Temple Stray Fairies in Great Bay/Final Room Upper Right Bubble",
  "@Woodfall Temple Stray Fairies in Great Bay/Final Room Upper Left Bubble",
  "@Woodfall Temple Stray Fairies in Great Bay/Final Room Pillar Bubble",

  --Woodfall Temple in Stone Tower
  "@Woodfall Temple in Stone Tower/Chest in Platform Room - Small Key",
  "@Woodfall Temple in Stone Tower/Fight Turtles - Map",
  "@Woodfall Temple in Stone Tower/Fight Dragonflies - Compass",
  "@Woodfall Temple in Stone Tower/Dinolfos Mini Boss - Hero's Bow",
  "@Woodfall Temple in Stone Tower/Boss Key Chest",
  "@Woodfall Temple in Stone Tower/Odolwa",
  "@Woodfall Temple in Stone Tower/Oath to Order",
  "@Woodfall Temple Stray Fairies in Stone Tower/Entrance Fairy",
  "@Woodfall Temple Stray Fairies in Stone Tower/Entrance Platform Chest",
  "@Woodfall Temple Stray Fairies in Stone Tower/Kill Deku Baba in Main Room",
  "@Woodfall Temple Stray Fairies in Stone Tower/Pots in Main Room",
  "@Woodfall Temple Stray Fairies in Stone Tower/Platform Room Beehive",
  "@Woodfall Temple Stray Fairies in Stone Tower/Kill Skulltula in Bridge Room",
  "@Woodfall Temple Stray Fairies in Stone Tower/Bridge Room Beehive",
  "@Woodfall Temple Stray Fairies in Stone Tower/Dark Room Black Boes",
  "@Woodfall Temple Stray Fairies in Stone Tower/Main Room Bubble",
  "@Woodfall Temple Stray Fairies in Stone Tower/Main Room Switch",
  "@Woodfall Temple Stray Fairies in Stone Tower/Bridge Room Bubble",
  "@Woodfall Temple Stray Fairies in Stone Tower/Final Room Lower Right Bubble",
  "@Woodfall Temple Stray Fairies in Stone Tower/Final Room Upper Right Bubble",
  "@Woodfall Temple Stray Fairies in Stone Tower/Final Room Upper Left Bubble",
  "@Woodfall Temple Stray Fairies in Stone Tower/Final Room Pillar Bubble",

  --Mountain Village
  "@Path to Goron Graveyard Grotto/After beating Snowhead Temple",
  "@Goron Graveyard/Heal Darmani",
  "@Mountain Smithy/Melt the ice and buy it for 100 Rupees - Day 1",
  "@Mountain Smithy/Show the Gold Dust - Day 2",
  "@Frog Choir/Gather the 5 frogs and beat Snowhead Temple",
  "@Deliver Rock Sirloin to hungry Goron/Get it from Goron Shrine",
  "@Mountain Village Hidden Waterfall Chest/After beating Snowhead Temple",

  --Twin Islands
  "@Goron Racetrack/Win Race After Beating Snowhead Temple",
  "@Twin Islands Ramps Secret Grotto/Bomb the tree near the ramps",
  "@Twin Islands Spring Chests/Gold Chest",
  "@Twin Islands Spring Chests/Chest Inside Nook",
  "@Twin Islands Hot Spring Water Grotto/Melt the ice",
  "@Mountain Tingle Maps/Map: Mountain",
  "@Mountain Tingle Maps/Map: Ranch",

  --Goron Village
  "@Baby Goron Teaching Lullaby/Talk to Baby Goron",
  "@Goron Shrine Shop/10 Bombs (40 Rupees)",
  "@Goron Shrine Shop/10 Arrows (40 Rupees)",
  "@Goron Shrine Shop/Red Potion (80 Rupees)",
  "@Goron Shrine Shop/Red Potion (80 Rupees)",
  "@Medigoron Powder Keg/Talk to him after opening the track",
  "@Mountain Business Scrub/Give Swamp Title Deed",
  "@Mountain Business Scrub/Buy Bomb Bag",
  "@Mountain Business Scrub/Use Flower",
  "@Lens Cave Chests/Lens chest",
  "@Lens Cave Chests/Invisible chest",
  "@Lens Cave Chests/Chest inside rock",

  --Snowhead Area
  "@Road to Snowhead/Get in the secret grotto",
  "@Road to Snowhead/Get the PoH",
  "@Snowhead Great Fairy Fountain/15 Stray Fairies in Snowhead Temple",

  --Snowhead Temple
  "@Snowhead Temple/Behind Double Blocks - Small Key",
  "@Snowhead Temple/Near Cracked Wall - Compass",
  "@Snowhead Temple/Chest Past Bridge Room - Map",
  "@Snowhead Temple/Icicle Room Snowball - Small Key",
  "@Snowhead Temple/Wizrobe Mini Boss - Fire Arrow",
  "@Snowhead Temple/Kill Freezards in Bridge Room - Small Key",
  "@Snowhead Temple/Boss Key Chest",
  "@Snowhead Temple/Goht",
  "@Snowhead Temple/Oath to Order",

  "@Snowhead Temple Stray Fairies/Bridge Room Ledge Bubble",
  "@Snowhead Temple Stray Fairies/Bridge Room Pillar Bubble",
  "@Snowhead Temple Stray Fairies/Map Room Ground Fairy",
  "@Snowhead Temple Stray Fairies/Crate Fairy",
  "@Snowhead Temple Stray Fairies/Icicle Room Fake Wall",
  "@Snowhead Temple Stray Fairies/Fake Ceiling Bubble Fairy",
  "@Snowhead Temple Stray Fairies/Map Room Ledge Chest",
  "@Snowhead Temple Stray Fairies/Basement Chest",
  "@Snowhead Temple Stray Fairies/Ice Puzzle Chest",
  "@Snowhead Temple Stray Fairies/Double Block Chest",
  "@Snowhead Temple Stray Fairies/Pillar Freezards",
  "@Snowhead Temple Stray Fairies/Snow Room Fake Wall",
  "@Snowhead Temple Stray Fairies/Dinolfos 1",
  "@Snowhead Temple Stray Fairies/Dinolfos 2",
  "@Snowhead Temple Stray Fairies/Main Room Fake Wall",

  --Snowhead Temple in Woodfall
  "@Snowhead Temple in Woodfall/Behind Double Blocks - Small Key",
  "@Snowhead Temple in Woodfall/Near Cracked Wall - Compass",
  "@Snowhead Temple in Woodfall/Chest Past Bridge Room - Map",
  "@Snowhead Temple in Woodfall/Icicle Room Snowball - Small Key",
  "@Snowhead Temple in Woodfall/Wizrobe Mini Boss - Fire Arrow",
  "@Snowhead Temple in Woodfall/Kill Freezards in Bridge Room - Small Key",
  "@Snowhead Temple in Woodfall/Boss Key Chest",
  "@Snowhead Temple in Woodfall/Goht",
  "@Snowhead Temple in Woodfall/Oath to Order",

  "@Snowhead Temple Stray Fairies in Woodfall/Bridge Room Ledge Bubble",
  "@Snowhead Temple Stray Fairies in Woodfall/Bridge Room Pillar Bubble",
  "@Snowhead Temple Stray Fairies in Woodfall/Map Room Ground Fairy",
  "@Snowhead Temple Stray Fairies in Woodfall/Crate Fairy",
  "@Snowhead Temple Stray Fairies in Woodfall/Icicle Room Fake Wall",
  "@Snowhead Temple Stray Fairies in Woodfall/Fake Ceiling Bubble Fairy",
  "@Snowhead Temple Stray Fairies in Woodfall/Map Room Ledge Chest",
  "@Snowhead Temple Stray Fairies in Woodfall/Basement Chest",
  "@Snowhead Temple Stray Fairies in Woodfall/Ice Puzzle Chest",
  "@Snowhead Temple Stray Fairies in Woodfall/Double Block Chest",
  "@Snowhead Temple Stray Fairies in Woodfall/Pillar Freezards",
  "@Snowhead Temple Stray Fairies in Woodfall/Snow Room Fake Wall",
  "@Snowhead Temple Stray Fairies in Woodfall/Dinolfos 1",
  "@Snowhead Temple Stray Fairies in Woodfall/Dinolfos 2",
  "@Snowhead Temple Stray Fairies in Woodfall/Main Room Fake Wall",

  --Snowhead Temple in Great Bay
  "@Snowhead Temple in Great Bay/Behind Double Blocks - Small Key",
  "@Snowhead Temple in Great Bay/Near Cracked Wall - Compass",
  "@Snowhead Temple in Great Bay/Chest Past Bridge Room - Map",
  "@Snowhead Temple in Great Bay/Icicle Room Snowball - Small Key",
  "@Snowhead Temple in Great Bay/Wizrobe Mini Boss - Fire Arrow",
  "@Snowhead Temple in Great Bay/Kill Freezards in Bridge Room - Small Key",
  "@Snowhead Temple in Great Bay/Boss Key Chest",
  "@Snowhead Temple in Great Bay/Goht",
  "@Snowhead Temple in Great Bay/Oath to Order",

  "@Snowhead Temple Stray Fairies in Great Bay/Bridge Room Ledge Bubble",
  "@Snowhead Temple Stray Fairies in Great Bay/Bridge Room Pillar Bubble",
  "@Snowhead Temple Stray Fairies in Great Bay/Map Room Ground Fairy",
  "@Snowhead Temple Stray Fairies in Great Bay/Crate Fairy",
  "@Snowhead Temple Stray Fairies in Great Bay/Icicle Room Fake Wall",
  "@Snowhead Temple Stray Fairies in Great Bay/Fake Ceiling Bubble Fairy",
  "@Snowhead Temple Stray Fairies in Great Bay/Map Room Ledge Chest",
  "@Snowhead Temple Stray Fairies in Great Bay/Basement Chest",
  "@Snowhead Temple Stray Fairies in Great Bay/Ice Puzzle Chest",
  "@Snowhead Temple Stray Fairies in Great Bay/Double Block Chest",
  "@Snowhead Temple Stray Fairies in Great Bay/Pillar Freezards",
  "@Snowhead Temple Stray Fairies in Great Bay/Snow Room Fake Wall",
  "@Snowhead Temple Stray Fairies in Great Bay/Dinolfos 1",
  "@Snowhead Temple Stray Fairies in Great Bay/Dinolfos 2",
  "@Snowhead Temple Stray Fairies in Great Bay/Main Room Fake Wall",
  
  -- Snowhead Temple in Stone Tower
  "@Snowhead Temple in Stone Tower/Behind Double Blocks - Small Key",
  "@Snowhead Temple in Stone Tower/Near Cracked Wall - Compass",
  "@Snowhead Temple in Stone Tower/Chest Past Bridge Room - Map",
  "@Snowhead Temple in Stone Tower/Icicle Room Snowball - Small Key",
  "@Snowhead Temple in Stone Tower/Wizrobe Mini Boss - Fire Arrow",
  "@Snowhead Temple in Stone Tower/Kill Freezards in Bridge Room - Small Key",
  "@Snowhead Temple in Stone Tower/Boss Key Chest",
  "@Snowhead Temple in Stone Tower/Goht",
  "@Snowhead Temple in Stone Tower/Oath to Order",

  "@Snowhead Temple Stray Fairies in Stone Tower/Bridge Room Ledge Bubble",
  "@Snowhead Temple Stray Fairies in Stone Tower/Bridge Room Pillar Bubble",
  "@Snowhead Temple Stray Fairies in Stone Tower/Map Room Ground Fairy",
  "@Snowhead Temple Stray Fairies in Stone Tower/Crate Fairy",
  "@Snowhead Temple Stray Fairies in Stone Tower/Icicle Room Fake Wall",
  "@Snowhead Temple Stray Fairies in Stone Tower/Fake Ceiling Bubble Fairy",
  "@Snowhead Temple Stray Fairies in Stone Tower/Map Room Ledge Chest",
  "@Snowhead Temple Stray Fairies in Stone Tower/Basement Chest",
  "@Snowhead Temple Stray Fairies in Stone Tower/Ice Puzzle Chest",
  "@Snowhead Temple Stray Fairies in Stone Tower/Double Block Chest",
  "@Snowhead Temple Stray Fairies in Stone Tower/Pillar Freezards",
  "@Snowhead Temple Stray Fairies in Stone Tower/Snow Room Fake Wall",
  "@Snowhead Temple Stray Fairies in Stone Tower/Dinolfos 1",
  "@Snowhead Temple Stray Fairies in Stone Tower/Dinolfos 2",
  "@Snowhead Temple Stray Fairies in Stone Tower/Main Room Fake Wall",

  --Milk Road
  "@Milk Road Tingle Maps/Map: Ranch",
  "@Milk Road Tingle Maps/Map: Ocean",
  "@Milk Road Gorman Brothers - Any Day/Win the race",
  "@Milk Road Gorman Brothers - Any Day/Buy Milk",

  --Romani Ranch
  "@Doggy Racetrack - Open 6AM to 8PM/Chest On Shed Roof",
  "@Doggy Racetrack - Open 6AM to 8PM/Earn 150 Rupees From Racing",

  "@Romani Ranch Cucco Shack/March with Bremen Mask",

  "@Romani Ranch Cows/Barn Cow 1",
  "@Romani Ranch Cows/Barn Cow 2",
  "@Romani Ranch Cows/Barn Cow Corner",
  "@Romani Ranch Aliens Quest/Day 1 - Romani Ranch Archery Training",
  "@Romani Ranch Aliens Quest/Night 1: 2:30 AM - 3:45 AM - Save the Cows",
  "@Romani Ranch Aliens Quest/Night 2: 6 PM - 7 PM - Escort Cremia after defeating Them",

  --Great Bay Coast
  "@Great Bay Coast Grotto/Grotto Behind Fisherman Hut",
  "@Fisherman's House/Show Photo of Gerudo Pirate",
  "@Great Bay Coast/Heal Mikau",
  "@Fisherman Island/Win it",
  "@Great Bay Coast Ledge/Great Bay Ledge Grotto Cow 1",
  "@Great Bay Coast Ledge/Great Bay Ledge Grotto Cow 2",
  "@Great Bay Coast Ledge/Great Bay Coast PoH",
  "@Ocean Tingle Maps/Map: Ocean",
  "@Ocean Tingle Maps/Map: Canyon",
  "@Marine Lab/Feed The Fish",
  "@Marine Lab/Song From Zora Eggs",

  --Oceanside Spider House
  "@Oceanside Spider House Skulltullas First 15/Entrance Slope Left",
  "@Oceanside Spider House Skulltullas First 15/Entrance Slope Right",
  "@Oceanside Spider House Skulltullas First 15/Entrance Web",
  "@Oceanside Spider House Skulltullas First 15/Main Room Behind Skull",
  "@Oceanside Spider House Skulltullas First 15/Main Room Webbed Pot",
  "@Oceanside Spider House Skulltullas First 15/Main Room Pot Upper",
  "@Oceanside Spider House Skulltullas First 15/Main Room Wooden Beam",
  "@Oceanside Spider House Skulltullas First 15/Library Corner Bookshelf",
  "@Oceanside Spider House Skulltullas First 15/Library Hole Behind Cabinets",
  "@Oceanside Spider House Skulltullas First 15/Library Ceiling Black Space",
  "@Oceanside Spider House Skulltullas First 15/Library Hole Behind Painting",
  "@Oceanside Spider House Skulltullas First 15/Library Behind Painting",
  "@Oceanside Spider House Skulltullas First 15/Library Behind Bookshelf 1",
  "@Oceanside Spider House Skulltullas First 15/Library Behind Bookshelf 2",
  "@Oceanside Spider House Skulltullas First 15/Main Room Basement Black Space",

  "@Oceanside Spider House Skulltullas Second 15/Main Room Basement Vase",
  "@Oceanside Spider House Skulltullas Second 15/Main Room Basement Behind Skull",
  "@Oceanside Spider House Skulltullas Second 15/Main Room Basement Web Hole",
  "@Oceanside Spider House Skulltullas Second 15/Main Room Basement Pot",
  "@Oceanside Spider House Skulltullas Second 15/Storage Room Crate",
  "@Oceanside Spider House Skulltullas Second 15/Storage Room Crate Alcove",
  "@Oceanside Spider House Skulltullas Second 15/Storage Room Behind Boat",
  "@Oceanside Spider House Skulltullas Second 15/Storage Room Rafters",
  "@Oceanside Spider House Skulltullas Second 15/Storage Room Web",
  "@Oceanside Spider House Skulltullas Second 15/Colored Mask Room Chandelier 1",
  "@Oceanside Spider House Skulltullas Second 15/Colored Mask Room Chandelier 2",
  "@Oceanside Spider House Skulltullas Second 15/Colored Mask Room Chandelier 3",
  "@Oceanside Spider House Skulltullas Second 15/Colored Mask Room Painting",
  "@Oceanside Spider House Skulltullas Second 15/Colored Mask Room Black Space",
  "@Oceanside Spider House Skulltullas Second 15/Colored Mask Room Vase",

  "@Oceanside Spider House/Collect 30 Tokens- Day 1",
  "@Oceanside Spider House/Collect 30 Tokens- Day 2",
  "@Oceanside Spider House/Collect 30 Tokens- Day 3",
  "@Oceanside Spider House/Ocean Spider Treasure",

  --Pirates' Fortress
  "@Pirates' Fortress Exterior/Near Gate",
  "@Pirates' Fortress Exterior/In Corner",
  "@Pirates' Fortress Exterior/Under Log",
  "@Pirates' Fortress Tunnel/PF Underwater Maze Chest",
  "@Pirates' Fortress Tunnel/PF Jail Room Underwater Chest 1",
  "@Pirates' Fortress Tunnel/PF Jail Room Underwater Chest 2",
  "@Pirates' Fortress Tunnel/PF Jail Room PoH",
  "@Pirates' Fortress/Lower Chest",
  "@Pirates' Fortress/Hookshot Chest",
  "@Pirates' Fortress/Upper Chest",
  "@Pirates' Fortress/Well Guarded Chest",
  "@Pirates' Fortress/Fish Tank Chest",

  --Pinnacle Rock
  "@Pinnacle Rock/Sea Snake Upper Chest",
  "@Pinnacle Rock/Sea Snake Lower Chest",
  "@Pinnacle Rock/Reunite The Seahorses",

  --Zora Cape
  "@Underwater Near Fairy Shrine/Zora Cape Underwater Chest",
  "@Zora Cape Grotto/Under The Rock By The Fairy Shrine",
  "@Great Bay Great Fairy Fountain/15 Stray Fairies in Great Bay Temple",
  "@Under The Waterfall/Zora Cape Like Like Treasure",
  "@Zora Cape Ledge/Zora Cape Ledge Chest",
  "@Zora Cape Ledge/Zora Cape Ledge Lower Chest",
  "@Waterfall Rapids/Beaver Brothers Race Prize",
  "@Waterfall Rapids/Beaver Brothers Race Rematch",

  --Zora Hall
  "@Zora Hall Shop/Shield (90 Rupees)",
  "@Zora Hall Shop/10 Arrows (20 Rupees)",
  "@Zora Hall Shop/Red Potion (60 Rupees)",
  "@Zora Hall/> > v A A v > A < < > v v > < v On Ocarina - Third Room Down",
  "@Zora Hall/Give Ocean Scrub The Mountain Title Deed - Fourth Room Down",
  "@Zora Hall/Buy Green Potion - 40 Rupees",
  "@Zora Hall/Show Upper Zora Bad Lulu Photo",
  "@Zora Hall/Show Upper Zora Good Lulu Photo",
  "@Zora Hall/Use Ocean Scrub Flower - Fourth Room Down",
  "@Zora Hall/Light the Upper Torches",

  --Great Bay Temple
  "@Great Bay Temple/Chest in Room with Ledges - Map",
  "@Great Bay Temple/Water Room Alcove - Compass",
  "@Great Bay Temple/Underwater Chest - Small Key",
  "@Great Bay Temple/Boss Key Chest",
  "@Great Bay Temple/Wart Miniboss - Ice Arrow",
  "@Great Bay Temple/Gyorg",
  "@Great Bay Temple/Oath to Order",
  "@Great Bay Temple Stray Fairies/Entrance Torches",
  "@Great Bay Temple Stray Fairies/Pinwheel Room Underwater Bubble",
  "@Great Bay Temple Stray Fairies/Pinwheel Room Skulltula",
  "@Great Bay Temple Stray Fairies/Main Room Barrel",
  "@Great Bay Temple Stray Fairies/Main Room Underwater Pot",
  "@Great Bay Temple Stray Fairies/Map Room Pot",
  "@Great Bay Temple Stray Fairies/Hallway Bio Babas",
  "@Great Bay Temple Stray Fairies/Dexihand Pot",
  "@Great Bay Temple Stray Fairies/Green Valve Ceiling",
  "@Great Bay Temple Stray Fairies/Waterwheel Room Lower",
  "@Great Bay Temple Stray Fairies/Waterwheel Room Upper",
  "@Great Bay Temple Stray Fairies/Seesaw Room Underwater Barrel",
  "@Great Bay Temple Stray Fairies/Seesaw Room Chest",
  "@Great Bay Temple Stray Fairies/Pre-Boss Exit Bubble",
  "@Great Bay Temple Stray Fairies/Pre-Boss Bubble",

  --Great Bay Temple in Woodfall
  "@Great Bay Temple in Woodfall/Chest in Room with Ledges - Map",
  "@Great Bay Temple in Woodfall/Water Room Alcove - Compass",
  "@Great Bay Temple in Woodfall/Underwater Chest - Small Key",
  "@Great Bay Temple in Woodfall/Boss Key Chest",
  "@Great Bay Temple in Woodfall/Wart Miniboss - Ice Arrow",
  "@Great Bay Temple in Woodfall/Gyorg",
  "@Great Bay Temple in Woodfall/Oath to Order",
  "@Great Bay Temple Stray Fairies in Woodfall/Entrance Torches",
  "@Great Bay Temple Stray Fairies in Woodfall/Pinwheel Room Underwater Bubble",
  "@Great Bay Temple Stray Fairies in Woodfall/Pinwheel Room Skulltula",
  "@Great Bay Temple Stray Fairies in Woodfall/Main Room Barrel",
  "@Great Bay Temple Stray Fairies in Woodfall/Main Room Underwater Pot",
  "@Great Bay Temple Stray Fairies in Woodfall/Map Room Pot",
  "@Great Bay Temple Stray Fairies in Woodfall/Hallway Bio Babas",
  "@Great Bay Temple Stray Fairies in Woodfall/Dexihand Pot",
  "@Great Bay Temple Stray Fairies in Woodfall/Green Valve Ceiling",
  "@Great Bay Temple Stray Fairies in Woodfall/Waterwheel Room Lower",
  "@Great Bay Temple Stray Fairies in Woodfall/Waterwheel Room Upper",
  "@Great Bay Temple Stray Fairies in Woodfall/Seesaw Room Underwater Barrel",
  "@Great Bay Temple Stray Fairies in Woodfall/Seesaw Room Chest",
  "@Great Bay Temple Stray Fairies in Woodfall/Pre-Boss Exit Bubble",
  "@Great Bay Temple Stray Fairies in Woodfall/Pre-Boss Bubble",

  --Great Bay Temple in Snowhead
  "@Great Bay Temple in Snowhead/Chest in Room with Ledges - Map",
  "@Great Bay Temple in Snowhead/Water Room Alcove - Compass",
  "@Great Bay Temple in Snowhead/Underwater Chest - Small Key",
  "@Great Bay Temple in Snowhead/Boss Key Chest",
  "@Great Bay Temple in Snowhead/Wart Miniboss - Ice Arrow",
  "@Great Bay Temple in Snowhead/Gyorg",
  "@Great Bay Temple in Snowhead/Oath to Order",
  "@Great Bay Temple Stray Fairies in Snowhead/Entrance Torches",
  "@Great Bay Temple Stray Fairies in Snowhead/Pinwheel Room Underwater Bubble",
  "@Great Bay Temple Stray Fairies in Snowhead/Pinwheel Room Skulltula",
  "@Great Bay Temple Stray Fairies in Snowhead/Main Room Barrel",
  "@Great Bay Temple Stray Fairies in Snowhead/Main Room Underwater Pot",
  "@Great Bay Temple Stray Fairies in Snowhead/Map Room Pot",
  "@Great Bay Temple Stray Fairies in Snowhead/Hallway Bio Babas",
  "@Great Bay Temple Stray Fairies in Snowhead/Dexihand Pot",
  "@Great Bay Temple Stray Fairies in Snowhead/Green Valve Ceiling",
  "@Great Bay Temple Stray Fairies in Snowhead/Waterwheel Room Lower",
  "@Great Bay Temple Stray Fairies in Snowhead/Waterwheel Room Upper",
  "@Great Bay Temple Stray Fairies in Snowhead/Seesaw Room Underwater Barrel",
  "@Great Bay Temple Stray Fairies in Snowhead/Seesaw Room Chest",
  "@Great Bay Temple Stray Fairies in Snowhead/Pre-Boss Exit Bubble",
  "@Great Bay Temple Stray Fairies in Snowhead/Pre-Boss Bubble",

  --Great Bay Temple in Stone Tower
  "@Great Bay Temple in Stone Tower/Chest in Room with Ledges - Map",
  "@Great Bay Temple in Stone Tower/Water Room Alcove - Compass",
  "@Great Bay Temple in Stone Tower/Underwater Chest - Small Key",
  "@Great Bay Temple in Stone Tower/Boss Key Chest",
  "@Great Bay Temple in Stone Tower/Wart Miniboss - Ice Arrow",
  "@Great Bay Temple in Stone Tower/Gyorg",
  "@Great Bay Temple in Stone Tower/Oath to Order",
  "@Great Bay Temple Stray Fairies in Stone Tower/Entrance Torches",
  "@Great Bay Temple Stray Fairies in Stone Tower/Pinwheel Room Underwater Bubble",
  "@Great Bay Temple Stray Fairies in Stone Tower/Pinwheel Room Skulltula",
  "@Great Bay Temple Stray Fairies in Stone Tower/Main Room Barrel",
  "@Great Bay Temple Stray Fairies in Stone Tower/Main Room Underwater Pot",
  "@Great Bay Temple Stray Fairies in Stone Tower/Map Room Pot",
  "@Great Bay Temple Stray Fairies in Stone Tower/Hallway Bio Babas",
  "@Great Bay Temple Stray Fairies in Stone Tower/Dexihand Pot",
  "@Great Bay Temple Stray Fairies in Stone Tower/Green Valve Ceiling",
  "@Great Bay Temple Stray Fairies in Stone Tower/Waterwheel Room Lower",
  "@Great Bay Temple Stray Fairies in Stone Tower/Waterwheel Room Upper",
  "@Great Bay Temple Stray Fairies in Stone Tower/Seesaw Room Underwater Barrel",
  "@Great Bay Temple Stray Fairies in Stone Tower/Seesaw Room Chest",
  "@Great Bay Temple Stray Fairies in Stone Tower/Pre-Boss Exit Bubble",
  "@Great Bay Temple Stray Fairies in Stone Tower/Pre-Boss Bubble",

  --Road to Ikana
  "@Chest on Ikana Pillar/Hookshot it",
  "@Shiro the Invisible Soldier/Give him a red potion",
  "@Road to Ikana Grotto/Get in",

  --Graveyard
  "@Ikana Graveyard Grotto/Bomb the circle of rocks",
  "@Ikana Graveyard Graves Night 1/Defeat all bats",
  "@Ikana Graveyard Graves Night 1/Defeat Iron Knuckle",
  "@Ikana Graveyard Graves Night 2/Defeat Iron Knuckle",
  "@Ikana Graveyard Graves Night 3/Defeat Big Poe",
  "@Captain Keeta's Hat Chest/Defeat Captain Keeta",

  --Ikana Canyon
  "@Ikana Canyon Business Scrub/Give Ocean Title Deed",
  "@Ikana Canyon Business Scrub/Buy Blue Potion - 100 Rupees",
  "@Ikana Canyon Business Scrub/Cross Canyon",
  "@Ikana Canyon Grotto/Behind the waterfall",
  "@Secret Shrine Miniboss Gauntlet/Dinolfos",
  "@Secret Shrine Miniboss Gauntlet/Wizrobe",
  "@Secret Shrine Miniboss Gauntlet/Wart",
  "@Secret Shrine Miniboss Gauntlet/Garo Master",
  "@Secret Shrine Miniboss Gauntlet/Defeat all four minibosses",
  "@Music Box House/Heal Pamela's father",
  "@Poe Shooting Game/Win it",
  "@Ikana Great Fairy Fountain/15 Stray Fairies in Stone Tower Temple",
  "@Ikana Canyon Tingle Maps/Map: Canyon",
  "@Ikana Canyon Tingle Maps/Map: Clock Town",

  --Ikana Castle
  "@Ancient Castle of Ikana/Defeat Igos Du Ikana",
  "@Ancient Castle of Ikana/Castle PoH",

  --Beneath the Well
  "@Beneath the Well/Mirror Shield Chest",
  "@Beneath the Well/Right Side Well Chest",
  "@Beneath the Well/Left Side Well Chest",
  "@Beneath the Well/Beneath the Well Cow",

  --Stone Tower
  "@Inverted Stone Tower Chests/Left Chest",
  "@Inverted Stone Tower Chests/Middle Chest",
  "@Inverted Stone Tower Chests/Right Chest",

  --Stone Tower Temple
  "@Stone Tower Temple/Lava Room Behind Sun Block - Map",
  "@Stone Tower Temple/Kill Armos in Lava Room - Small Key",
  "@Stone Tower Temple/Across Water in Bridge Room - Small Key",
  "@Stone Tower Temple/Behind Sun Block - Compass",
  "@Stone Tower Temple/Garo Master Miniboss - Light Arrow",
  "@Stone Tower Temple Stray Fairies/Shoot the Statue Eye",
  "@Stone Tower Temple Stray Fairies/Basement Ceiling Chest",
  "@Stone Tower Temple Stray Fairies/Mirror Room Sun Switch",
  "@Stone Tower Temple Stray Fairies/Mirror Room Right Block",
  "@Stone Tower Temple Stray Fairies/Lava Room Fire Ring",
  "@Stone Tower Temple Stray Fairies/Lava Room Ledge",
  "@Stone Tower Temple Stray Fairies/Eyegore Chest",
  "@Stone Tower Temple Stray Fairies/Underwater Chest",
  "@Stone Tower Temple Stray Fairies/Death Armos Switch Chest in Inverted",
  "@Stone Tower Temple Stray Fairies/Bridge Room Crystal Switch",
  "@Stone Tower Temple Stray Fairies/Pre-Boss Crystal Switch",

  --Inverted Stone Tower Temple
  "@Inverted Stone Tower Temple/Across Bridge - Small Key",
  "@Inverted Stone Tower Temple/Chest on Fire - Small Key",
  "@Inverted Stone Tower Temple/Defeat Eyegore - Giant's Mask",
  "@Inverted Stone Tower Temple/Inverted Stone Tower Temple Boss Key Chest",
  "@Inverted Stone Tower Temple/Twinmold",
  "@Inverted Stone Tower Temple/Oath to Order",
  "@Inverted Stone Tower Temple Stray Fairies/Inverted Entrance Sun",
  "@Inverted Stone Tower Temple Stray Fairies/Updraft Room Flaming Chest",
  "@Inverted Stone Tower Temple Stray Fairies/Updraft Frozen Eye Chest",
  "@Inverted Stone Tower Temple Stray Fairies/After Wizrobe Chest",

  --Inverted Stone Tower in Woodfall
  "@Inverted Stone Tower Temple in Woodfall/Across Bridge - Small Key",
  "@Inverted Stone Tower Temple in Woodfall/Chest on Fire - Small Key",
  "@Inverted Stone Tower Temple in Woodfall/Defeat Eyegore - Giant's Mask",
  "@Inverted Stone Tower Temple in Woodfall/Inverted Stone Tower Temple Boss Key Chest",
  "@Inverted Stone Tower Temple in Woodfall/Twinmold",
  "@Inverted Stone Tower Temple in Woodfall/Oath to Order",
  "@Inverted Stone Tower Temple Stray Fairies in Woodfall/Inverted Entrance Sun",
  "@Inverted Stone Tower Temple Stray Fairies in Woodfall/Updraft Room Flaming Chest",
  "@Inverted Stone Tower Temple Stray Fairies in Woodfall/Updraft Frozen Eye Chest",
  "@Inverted Stone Tower Temple Stray Fairies in Woodfall/After Wizrobe Chest",
  --Inverted Stone Tower in Snowhead
  "@Inverted Stone Tower Temple in Snowhead/Across Bridge - Small Key",
  "@Inverted Stone Tower Temple in Snowhead/Chest on Fire - Small Key",
  "@Inverted Stone Tower Temple in Snowhead/Defeat Eyegore - Giant's Mask",
  "@Inverted Stone Tower Temple in Snowhead/Inverted Stone Tower Temple Boss Key Chest",
  "@Inverted Stone Tower Temple in Snowhead/Twinmold",
  "@Inverted Stone Tower Temple in Snowhead/Oath to Order",
  "@Inverted Stone Tower Temple Stray Fairies in Snowhead/Inverted Entrance Sun",
  "@Inverted Stone Tower Temple Stray Fairies in Snowhead/Updraft Room Flaming Chest",
  "@Inverted Stone Tower Temple Stray Fairies in Snowhead/Updraft Frozen Eye Chest",
  "@Inverted Stone Tower Temple Stray Fairies in Snowhead/After Wizrobe Chest",
  --Inverted Stone Tower in Great Bay
  "@Inverted Stone Tower Temple in Great Bay/Across Bridge - Small Key",
  "@Inverted Stone Tower Temple in Great Bay/Chest on Fire - Small Key",
  "@Inverted Stone Tower Temple in Great Bay/Defeat Eyegore - Giant's Mask",
  "@Inverted Stone Tower Temple in Great Bay/Inverted Stone Tower Temple Boss Key Chest",
  "@Inverted Stone Tower Temple in Great Bay/Twinmold",
  "@Inverted Stone Tower Temple in Great Bay/Oath to Order",
  "@Inverted Stone Tower Temple Stray Fairies in Great Bay/Inverted Entrance Sun",
  "@Inverted Stone Tower Temple Stray Fairies in Great Bay/Updraft Room Flaming Chest",
  "@Inverted Stone Tower Temple Stray Fairies in Great Bay/Updraft Frozen Eye Chest",
  "@Inverted Stone Tower Temple Stray Fairies in Great Bay/After Wizrobe Chest",
}

CaptureBadgeCache = {}

function tracker_on_accessibility_updated()
  for i,section in pairs(CaptureBadgeSections) do
      local target = Tracker:FindObjectForCode(section)
      -- Has the captured item for this section changed since last update
      if target == nil then
          print("Failed to resolve " .. section .. " please check for typos.")
      elseif target.CapturedItem ~= CaptureBadgeCache[target] then
          -- Does the location that owns this section already have a badge, if so remove it
          if CaptureBadgeCache[target.Owner] then
              target.Owner:RemoveBadge(CaptureBadgeCache[target.Owner])
              CaptureBadgeCache[target.Owner] = nil
              CaptureBadgeCache[target] = nil
          end
          -- Check if a captured item exists, add as badge to the sections owner if it does
          if target.CapturedItem then
              CaptureBadgeCache[target.Owner] = target.Owner:AddBadge(target.CapturedItem.PotentialIcon)
              CaptureBadgeCache[target] = target.CapturedItem
          end
      end
  end


  local swampmap1 = Tracker:FindObjectForCode("@Clock Town Tingle Maps/Map: Swamp")
  local swampmap2 = Tracker:FindObjectForCode("@Swamp Tingle Maps/Map: Swamp")
  
  local mountainmap1 = Tracker:FindObjectForCode("@Swamp Tingle Maps/Map: Mountain")
  local mountainmap2 = Tracker:FindObjectForCode("@Mountain Tingle Maps/Map: Mountain")
  
  local oceanmap1 = Tracker:FindObjectForCode("@Milk Road Tingle Maps/Map: Ocean")
  local oceanmap2 = Tracker:FindObjectForCode("@Ocean Tingle Maps/Map: Ocean")
  
  local canyonmap1 = Tracker:FindObjectForCode("@Ocean Tingle Maps/Map: Canyon")
  local canyonmap2 = Tracker:FindObjectForCode("@Ikana Canyon Tingle Maps/Map: Canyon")
  
  local ranchmap1 = Tracker:FindObjectForCode("@Mountain Tingle Maps/Map: Ranch")
  local ranchmap2 = Tracker:FindObjectForCode("@Milk Road Tingle Maps/Map: Ranch")
  
  local townmap1 = Tracker:FindObjectForCode("@Clock Town Tingle Maps/Map: Clock Town")
  local townmap2 = Tracker:FindObjectForCode("@Ikana Canyon Tingle Maps/Map: Clock Town")
  
  local woodfall_oath = Tracker:FindObjectForCode("@Woodfall Temple/Oath to Order")
  local snowhead_oath = Tracker:FindObjectForCode("@Snowhead Temple/Oath to Order")
  local greatbay_oath = Tracker:FindObjectForCode("@Great Bay Temple/Oath to Order")
  local stonetower_oath = Tracker:FindObjectForCode("@Stone Tower Temple/Oath to Order")
  
  if swampmap1 and swampmap2 then
      if (swampmap1.AvailableChestCount == 0) or (swampmap2.AvailableChestCount == 0) then
          swampmap1.AvailableChestCount = 0
          swampmap2.AvailableChestCount = 0
      end
  end
  
  if mountainmap1 and mountainmap2 then
      if (mountainmap1.AvailableChestCount == 0) or (mountainmap2.AvailableChestCount == 0) then
          mountainmap1.AvailableChestCount = 0
          mountainmap2.AvailableChestCount = 0
      end
  end
  
  if oceanmap1 and oceanmap2 then
      if (oceanmap1.AvailableChestCount == 0) or (oceanmap2.AvailableChestCount == 0) then
          oceanmap1.AvailableChestCount = 0
          oceanmap2.AvailableChestCount = 0
      end
  end
  
  if canyonmap1 and canyonmap2 then
      if (canyonmap1.AvailableChestCount == 0) or (canyonmap2.AvailableChestCount == 0) then
          canyonmap1.AvailableChestCount = 0
          canyonmap2.AvailableChestCount = 0
      end
  end
  
  if ranchmap1 and ranchmap2 then
      if (ranchmap1.AvailableChestCount == 0) or (ranchmap2.AvailableChestCount == 0) then
          ranchmap1.AvailableChestCount = 0
          ranchmap2.AvailableChestCount = 0
      end
  end
  
  if townmap1 and townmap2 then
      if (townmap1.AvailableChestCount == 0) or (townmap2.AvailableChestCount == 0) then
          townmap1.AvailableChestCount = 0
          townmap2.AvailableChestCount = 0
      end
  end
  
  if woodfall_oath and snowhead_oath and greatbay_oath and stonetower_oath then
      if (woodfall_oath.AvailableChestCount == 0)
      or (snowhead_oath.AvailableChestCount == 0)
      or (greatbay_oath.AvailableChestCount == 0)
      or (stonetower_oath.AvailableChestCount == 0) then
          woodfall_oath.AvailableChestCount = 0
          snowhead_oath.AvailableChestCount = 0
          greatbay_oath.AvailableChestCount = 0
          stonetower_oath.AvailableChestCount = 0
      end
  end



-- dont even bother trying to analyze this it's part of the dungeon er compatibility

  if Tracker:ProviderCountForCode("gohtlocwood") > 0 then
    Tracker:FindObjectForCode("gohtsnow").CurrentStage = 4
  elseif Tracker:ProviderCountForCode("odolwalocwood") > 0 then
    Tracker:FindObjectForCode("odolwawood").CurrentStage = 1

elseif Tracker:ProviderCountForCode("gyorglocwood") > 0 then
    Tracker:FindObjectForCode("gyorgbay").CurrentStage = 3

elseif Tracker:ProviderCountForCode("twinlocwood") > 0 then
    Tracker:FindObjectForCode("twinwood").CurrentStage = 2

elseif Tracker:ProviderCountForCode("gohtlocsnow") > 0 then
    Tracker:FindObjectForCode("gohtsnow").CurrentStage = 0

  elseif Tracker:ProviderCountForCode("odolwalocsnow") > 0 then
    Tracker:FindObjectForCode("odolwawood").CurrentStage = 2
    
elseif Tracker:ProviderCountForCode("gyorglocsnow") > 0 then
    Tracker:FindObjectForCode("gyorgbay").CurrentStage = 4

elseif Tracker:ProviderCountForCode("twinlocsnow") > 0 then
    Tracker:FindObjectForCode("twinstone").CurrentStage = 3

    elseif Tracker:ProviderCountForCode("gohtlocbay") > 0 then
    Tracker:FindObjectForCode("gohtsnow").CurrentStage = 1

  elseif Tracker:ProviderCountForCode("odolwalocbay") > 0 then
    Tracker:FindObjectForCode("odolwawood").CurrentStage = 3
    
elseif Tracker:ProviderCountForCode("gyorglocbay") > 0 then
    Tracker:FindObjectForCode("gyorgbay").CurrentStage = 0
    
elseif Tracker:ProviderCountForCode("twinlocbay") > 0 then
    Tracker:FindObjectForCode("twinstone").CurrentStage = 4

elseif Tracker:ProviderCountForCode("gohtlocstone") > 0 then
    Tracker:FindObjectForCode("gohtsnow").CurrentStage = 2

  elseif Tracker:ProviderCountForCode("odolwalocstone") > 0 then
    Tracker:FindObjectForCode("odolwawood").CurrentStage = 4
    
elseif Tracker:ProviderCountForCode("gyorglocstone") > 0 then
    Tracker:FindObjectForCode("gyorgbay").CurrentStage = 1
    
elseif Tracker:ProviderCountForCode("twinlocstone") > 0 then
    Tracker:FindObjectForCode("twinstone").CurrentStage = 0
  else
      return 0 
   
end



if Tracker:ProviderCountForCode("gohtlocwood") > 0 then
    Tracker:FindObjectForCode("gohtlocwood").CurrentStage = 0
elseif Tracker:ProviderCountForCode("odolwalocwood") > 0 then
    Tracker:FindObjectForCode("odolwalocwood").CurrentStage = 0
elseif Tracker:ProviderCountForCode("gyorglocwood") > 0 then
    Tracker:FindObjectForCode("gyorglocwood").CurrentStage = 0
elseif Tracker:ProviderCountForCode("twinlocwood") > 0 then
    Tracker:FindObjectForCode("twinlocwood").CurrentStage = 0
elseif Tracker:ProviderCountForCode("gohtlocsnow") > 0 then
        Tracker:FindObjectForCode("gohtlocsnow").CurrentStage = 0
elseif Tracker:ProviderCountForCode("odolwalocsnow") > 0 then
        Tracker:FindObjectForCode("odolwalocsnow").CurrentStage = 0
elseif Tracker:ProviderCountForCode("gyorglocsnow") > 0 then
        Tracker:FindObjectForCode("gyorglocsnow").CurrentStage = 0
elseif Tracker:ProviderCountForCode("twinlocsnow") > 0 then
        Tracker:FindObjectForCode("twinlocsnow").CurrentStage = 0
    elseif Tracker:ProviderCountForCode("gohtlocbay") > 0 then
        Tracker:FindObjectForCode("gohtlocbay").CurrentStage = 0
elseif Tracker:ProviderCountForCode("odolwalocbay") > 0 then
        Tracker:FindObjectForCode("odolwalocbay").CurrentStage = 0
elseif Tracker:ProviderCountForCode("gyorglocbay") > 0 then
        Tracker:FindObjectForCode("gyorglocbay").CurrentStage = 0
elseif Tracker:ProviderCountForCode("twinlocbay") > 0 then
        Tracker:FindObjectForCode("twinlocbay").CurrentStage = 0
            elseif Tracker:ProviderCountForCode("gohtlocstone") > 0 then
        Tracker:FindObjectForCode("gohtlocstone").CurrentStage = 0
elseif Tracker:ProviderCountForCode("odolwalocstone") > 0 then
        Tracker:FindObjectForCode("odolwalocstone").CurrentStage = 0
elseif Tracker:ProviderCountForCode("gyorglocstone") > 0 then
        Tracker:FindObjectForCode("gyorglocstone").CurrentStage = 0
elseif Tracker:ProviderCountForCode("twinlocstone") > 0 then
        Tracker:FindObjectForCode("twinlocstone").CurrentStage = 0
else 
          return 0

   
end









  
  local swampmap1 = Tracker:FindObjectForCode("@Clock Town Tingle Maps/Map: Swamp")
  local swampmap2 = Tracker:FindObjectForCode("@Swamp Tingle Maps/Map: Swamp")
  
  local mountainmap1 = Tracker:FindObjectForCode("@Swamp Tingle Maps/Map: Mountain")
  local mountainmap2 = Tracker:FindObjectForCode("@Mountain Tingle Maps/Map: Mountain")
  
  local oceanmap1 = Tracker:FindObjectForCode("@Milk Road Tingle Maps/Map: Ocean")
  local oceanmap2 = Tracker:FindObjectForCode("@Ocean Tingle Maps/Map: Ocean")
  
  local canyonmap1 = Tracker:FindObjectForCode("@Ocean Tingle Maps/Map: Canyon")
  local canyonmap2 = Tracker:FindObjectForCode("@Ikana Canyon Tingle Maps/Map: Canyon")
  
  local ranchmap1 = Tracker:FindObjectForCode("@Mountain Tingle Maps/Map: Ranch")
  local ranchmap2 = Tracker:FindObjectForCode("@Milk Road Tingle Maps/Map: Ranch")
  
  local townmap1 = Tracker:FindObjectForCode("@Clock Town Tingle Maps/Map: Clock Town")
  local townmap2 = Tracker:FindObjectForCode("@Ikana Canyon Tingle Maps/Map: Clock Town")
  
  local woodfall_oath = Tracker:FindObjectForCode("@Woodfall Temple/Oath to Order")
  local snowhead_oath = Tracker:FindObjectForCode("@Snowhead Temple/Oath to Order")
  local greatbay_oath = Tracker:FindObjectForCode("@Great Bay Temple/Oath to Order")
  local stonetower_oath = Tracker:FindObjectForCode("@Stone Tower Temple/Oath to Order")
  
  if swampmap1 and swampmap2 then
      if (swampmap1.AvailableChestCount == 0) or (swampmap2.AvailableChestCount == 0) then
          swampmap1.AvailableChestCount = 0
          swampmap2.AvailableChestCount = 0
      end
  end
  
  if mountainmap1 and mountainmap2 then
      if (mountainmap1.AvailableChestCount == 0) or (mountainmap2.AvailableChestCount == 0) then
          mountainmap1.AvailableChestCount = 0
          mountainmap2.AvailableChestCount = 0
      end
  end
  
  if oceanmap1 and oceanmap2 then
      if (oceanmap1.AvailableChestCount == 0) or (oceanmap2.AvailableChestCount == 0) then
          oceanmap1.AvailableChestCount = 0
          oceanmap2.AvailableChestCount = 0
      end
  end
  
  if canyonmap1 and canyonmap2 then
      if (canyonmap1.AvailableChestCount == 0) or (canyonmap2.AvailableChestCount == 0) then
          canyonmap1.AvailableChestCount = 0
          canyonmap2.AvailableChestCount = 0
      end
  end
  
  if ranchmap1 and ranchmap2 then
      if (ranchmap1.AvailableChestCount == 0) or (ranchmap2.AvailableChestCount == 0) then
          ranchmap1.AvailableChestCount = 0
          ranchmap2.AvailableChestCount = 0
      end
  end
  
  if townmap1 and townmap2 then
      if (townmap1.AvailableChestCount == 0) or (townmap2.AvailableChestCount == 0) then
          townmap1.AvailableChestCount = 0
          townmap2.AvailableChestCount = 0
      end
  end
  
  if woodfall_oath and snowhead_oath and greatbay_oath and stonetower_oath then
      if (woodfall_oath.AvailableChestCount == 0)
      or (snowhead_oath.AvailableChestCount == 0)
      or (greatbay_oath.AvailableChestCount == 0)
      or (stonetower_oath.AvailableChestCount == 0) then
          woodfall_oath.AvailableChestCount = 0
          snowhead_oath.AvailableChestCount = 0
          greatbay_oath.AvailableChestCount = 0
          stonetower_oath.AvailableChestCount = 0
      end
  end
end

